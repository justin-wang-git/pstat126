imports <- read.csv(file = "imports-85.data", sep = ",", header = TRUE)
imports[imports == 0] <- NA
na.aggregate(imports)
x1 <- imports$wheel.base
x2 <- imports$length
x3 <- imports$width
x4 <- imports$height
x5 <- imports$curb.weight
x6 <- imports$engine.size
x7 <- imports$bore #don't use this
x8 <- imports$stroke #don't use this
x9 <- imports$compression.ratio
x10 <- imports$horsepower #don't use this
x11 <- imports$peak.rpm #don't use this
x12 <- imports$city.mpg
x13 <- imports$highway.mpg
x14 <- imports$Symboling
y <- imports$price  

# What variables predict length the best? Which ones are most significant? 

fit <- lm(y ~ x1 + x2 + x3 + x4 + x5 + x6 + x7 + x8 + x9 + x10 + x11 + x12 + x13)
summary(fit)

# x1, x6, x8, x9, x11, x12
step(fit)
newfit <- lm(y ~ x1 + x6 + x8 + x9 + x11 + x12)
# step function confirms summary information

yhat = fitted(newfit)
e = residuals(newfit)

plot(yhat, e, xlab = 'Fitted Values', ylab = 'Residual', main = 'Residual vs Fit')
abline(h = 0, lty = 2)

qqnorm(e, main = "Normal Q-Q Plot")
qqline(e, col = 'blue')

bc<-boxCox(newfit)
bc$x[which.max(bc$y)]

#transformed

newfit2 <- lm(y**(-0.2626263) ~ x1 + x6 + x8 + x9 + x11 + x12)  

yhat2 = fitted(newfit2)
e2 = residuals(newfit2)

plot(yhat2, e2, xlab = 'Fitted Values', ylab = 'Residual', main = 'Residual vs Fit')
abline(h = 0, lty = 2)

qqnorm(e2, main = "Normal Q-Q Plot")
qqline(e2, col = 'blue')

summary(newfit2)

maxpredict <- data.frame(x1 = 120.9, x6 = 326, x8 = 4.17, x9 = 23, x11 = 6600, x12 = 49)
predict(newfit2, maxpredict, interval = "predict", level = 0.95)

confidence <- data.frame(x1 = mean(x1, na.rm = TRUE), x6 = mean(x6, na.rm = TRUE), x8 = mean(x8, na.rm = TRUE), x9 = mean(x9, na.rm = TRUE), x11 = mean(x11, na.rm = TRUE), x12 = mean(x12, na.rm = TRUE))
predict(newfit2, confidence, interval="confidence", level = 0.95)

test <- 0.06100472**(-1/0.2626263)