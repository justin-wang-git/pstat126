#PSTAT 126 HW 1
#Justin Wang
#6949184

#1 a) 
x1 <- wblake$Age
y1 <- wblake$Length
plot(x1, y1, xlab = "Age at Capture (in yrs)", 
             ylab = "Length at Capture (in mm)", 
             main = "West Bearskin Lake Small Mouth Bass")
n <- length(y1)

#regression 
Ex <- mean(x1)
Ey <- mean(y1)
Sxx <- sum((x1 - Ex)^2)
Syy <- sum((y1 - Ey)^2)
Sxy <- sum((x1-Ex)*(y1-Ey))
abline(b0, b1, col = "blue")

#estimates
b1 <- Sxy/Sxx
b0 <- Ey - b1*Ex

#standard errors
sse1 <- sum((y1-yhat1)^2)
mse1 <- sse1/(n-2)
se_b1 <- sqrt(mse1/Sxx)  
se_b0 <-sqrt(mse1*((1/n)+(Ex^2/Sxx))) 

#coefficient of determination
yhat1 <- b0 + b1*x1
ssr1 <- sum((yhat1-Ey)^2)
ssto1 <- sum((y1-Ey)^2)
corrCoeff1 <- ssr1/ssto1

#estimate of variance 
estvariance <- ssto1/(n-1)

#1 b) 99% confidence interval for B1
t_pct = qt(p = .995, df = n - 2)
ci_b1_99 = b1 + c(-1, 1)*t_pct*se_b1
#I am 99% confident that the true population slope of length on age lies between 63.64792 and 67.30640.

#1 c) 99% prediction interval for small mouth bass age 1
attach(wblake)
fit <- lm(Length ~ Age)
new <- data.frame(Age = 1)
predict(fit, new, interval = "predict", level = 0.99)
#I am 99% confident that the true population length of small mouth bass aged 1 lies between 21.43775 mm and 170.2644 mm.


#2 a) 
x2 <- Heights$mheight
y2 <- Heights$dheight
plot(x2, y2,  xlab = "Mother's Height (in in)", 
              ylab = "Daughter's Height (in in)", 
              main = "Mother/Daughter height")
n2 <- length(y2)

#regression 
Ex2 <- mean(x2)
Ey2 <- mean(y2)
Sxx2 <- sum((x2 - Ex2)^2)
Syy2 <- sum((y2 - Ey2)^2)
Sxy2 <- sum((x2-Ex2)*(y2-Ey2))
abline(b02, b12, col = "blue")

#estimates
b12 <- Sxy2/Sxx2
b02 <- Ey2 - b12*Ex2

#standard errors
sse2 <- sum((y2-yhat2)^2)
mse2 <- sse2/(n2-2)
se_b12 <- sqrt(mse2/Sxx2)  
se_b02 <-sqrt(mse2*((1/n2)+(Ex2^2/Sxx2))) 

#coefficient of determination
yhat2 <- b02 + b12*x2
ssr2 <- sum((yhat2-Ey2)^2)
ssto2 <- sum((y2-Ey2)^2)
corrCoeff2 <- ssr2/ssto2

#estimate of variance 
estvariance2 <- Syy2/(n2-1)

#2 b)
# When the mother's height is 0 inches, the daughter's height is 29.91744 inches.
# For every 1 inch positive change in the mother's height, there is a 0.5 inch increase in the daughter's predicted height.

#2 c)
attach(Heights)
fit2 <- lm(dheight ~ mheight)
new2 <- data.frame(mheight = 64)
predict(fit2, new2, interval = "predict", level = 0.99)

#3 d)
x3 <- seq(0, 1, length = 100)
y3 <- 1 + 2 * x3 + rnorm(100)
i <- seq(1, 1, length = 100)
xmatrix <- cbind(matrix(i, nrow = 100), matrix(x3, nrow = 100))
ymatrix <- matrix(y3, nrow = 100)
b <- solve(t(xmatrix)%*%xmatrix)%*%t(xmatrix)%*%ymatrix
fit3 <- lm(y3 ~ x3)
summary(fit3)$coefficients

#4 a)
# points above the line have an increase in the rice price between 2003 and 2009 and points below the line have a price decrease / no change 
# in the rice price.  

#4 b)
# Vilnius has the highest increase in rice price between 2003 and 2009.
# Mumbai has the largest decrease in rice price between 2003 and 2009.

#4 c)
# There isn't an obvious relationship between the predictor variable and the response variable.  

#4 d)
# The dataset is skewed heavily between 0 and 20 for prices in both 2003 and 2009.  
# Using the log scale for linear regression has a more normalized dataset for analysis.  