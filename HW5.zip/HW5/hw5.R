#1
library(faraway)
data("divusa")

x11 <- divusa$year
x21 <- divusa$unemployed
x31 <- divusa$femlab
x41 <- divusa$marriage
x51 <- divusa$birth
x61 <- divusa$military
y1 <- divusa$divorce

#a)
model0 <- lm(y1 ~ 1)
fullmodel1 <- lm(y1 ~ x11 + x21 + x31 + x41 + x51 + x61)
step(model0, scope = list(lower = model0, upper = fullmodel1))
model <- regsubsets(cbind(x11, x21, x31, x41), y1)

#b)
summary(model)$which
summary(model)$adjr2

#c)
summary(model)$which
summary(model)$cp

#2
#a)
jobproficiency <- read.csv(file = "Job proficiency.csv", sep = ",", header = TRUE)
y <- jobproficiency$y
x1 <- jobproficiency$x1
x2 <- jobproficiency$x2
x3 <- jobproficiency$x3
x4 <- jobproficiency$x4
pairs(~y + x1 + x2 + x3 + x4)
cor(jobproficiency)
# x3 and x4 have a strong linear relationship with y.  x1 has a slight linear relationship with y. 

#b) 
models <- regsubsets(cbind(x1, x2, x3, x4), y)
summary(models)$which
summary(models)$adjr2

#c) 
# I would probably use other AIC and C_p.

#3
#a) 
fullmodel <- lm(y ~ x1 + x2 + x3 + x4)
model1 <- lm(y ~ 1)
add1(model1, scope = fullmodel, test = "F")
model2 <- update(model1, .~. + x3)
add1(model2, scope = fullmodel, test = "F")
model3 <- update(model2, .~. + x1) 
drop1(model3, test = "F")
add1(model3, scope = fullmodel, test = "F")
model4 <- update(model3, .~. + x4)
drop1(model4, test = "F" )
add1( model4, scope = fullmodel, test="F" )

#b) 
# The model is the similar to the one I obtained in question 2, and includes x4. 
  
#4
#a) 
brandpreference <- read.csv(file = "brand preference.csv", sep = ",", header = TRUE)
x12 <- brandpreference$x1
x22 <- brandpreference$x2
y2 <- brandpreference$y

fit = lm(y2 ~ x12 + x22)
(rstudent(fit))
n=16
p=3
ifelse(rstudent(fit) > qt(1-0.95/2/n,n-p-1), "outlier", "Non-outlier") 

#b)
(h.lm=round(hatvalues(fit), 3))

#c)
# I would say that none of these values are high leverage points.  


#5
library(matlib)
X <- c(4, 1, 2, 3, 3, 4)
Y <- c(16, 5, 10, 15, 13, 22)


Xmatrix <- matrix(c(rep(1, times = 6), 4, 1, 2, 3, 3, 4), nrow = 6, ncol = 2, byrow = FALSE)
Xmatrix

#b)
XX <- t(X) %*% X
XY <- t(X) %*% Y
b <- solve(XX) %*% XY

#c )
hat <- X %*% solve(XX) %*% t(X)

#6
# It's easier to add variables to your model with a larger alpha.  
