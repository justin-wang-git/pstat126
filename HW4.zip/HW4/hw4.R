#1
data("water")
#a)

#b)

#c)


#2
#a)
data("lathe1")
life <- lathe1$Life
speed <- lathe1$Speed
feed <- lathe1$Feed
speedsq <- speed^2
feedsq <- feed^2

fit <- lm(life~speed+feed+speedsq+feedsq+speed*feed)
bc<-boxCox(fit)

#b) 
# $H_0: \beta_1 = \beta_2= \beta_{11}=\beta_{12} = \beta_{22} = 0$
# $H_1:$ At least one $\beta_k \neq 0$

loglife <- log(life)
reduced <- lm(loglife~1)
full <- lm(loglife ~ speed + feed + speedsq + feedsq + speed*feed)
anova(reduced, full)

#c) H_0 : means that Speed, Speed^2, and speed * feed do not have a relationship with life

#d) 
newreduced <- lm(loglife ~ speed + speedsq + speed*feed)
anova(newreduced, full)
# P-value very small, can't reject the null hypothesis.  

#3
#a) df = 1
  # Mean Square = Sum of Square / df
  # F-test = Mean Square for model / mean square for error
  SSTO <- 17.90761 / (1 - 0.637) 
  SSR <- SSTO - 17.90761
  df <- 2
  MeanSquare <- SSR / df
  fstat <- MeanSquare q/ 0.15306
  dftotal <- 119
  p <- pf(102.6457, 2, 117, lower.tail = FALSE)
  
#b) H_0, b_1 and b_2 = 0
  # H_1, b_1 or b_2 neq 0

#c) estimated value of variance based on results
MSE is an estimated value of variance because it is unbiased

#4
#a)
X <- c(0, 1, 0, 1, 0, 1, 1, 1)
Y <- c(474, 619, 584, 638, 399, 481, 624, 582)

fit = lm(Y ~ X)

#b)
X_0 <- c(0, 0, 0)
Y_0 <- c(474, 584, 399)

fit0 = lm(Y_0 ~ X_0)

X_1 <- c(1, 1, 1, 1, 1)
Y_1 <- c(619, 638, 481, 624, 582)

fit1 = lm(Y_1 ~ X_1)

#c)
t.test(Y ~ X)


#5
#a
# winter y = beta0 + beta1 * x1
# spring y = beta0 + beta2 * x2
# fall y = beta0 + beta3 * x3
# summer y = beta0

#c
#i beta_0 is the unchanged price
#ii beta_1 is the change in price for the winter
#iii beta_2 is the change in price for the spring
#iv beta_3 is the change in the price for the fall