#PSTAT 126 HW 1
#Justin Wang
#6949184

#1 a) The predictor variable is height and the response variable is weight.  

#1 b)
x <- Htwt$ht
y <- Htwt$wt
plot(x, y, xlab = "Height (in cm)", ylab = "Weight (in kg)", 
     main = "Height vs. Weight of 18 Year Old Girls")
#1 b) cont.  Simple linear regression would make sense for this data
# because there are only 2 variables in this datatset and we can easily analyze 
# the relationship between the two. 

#1 c)
Ex <- mean(x)
Ey <- mean(y)
Sxx <- sum((x - Ex)^2)
Syy <- sum((y - Ey)^2)
Sxy <- sum((x-Ex)*(y-Ey))
b1 <- Sxy/Sxx
b0 <- Ey - b1*Ex
abline(b0, b1, col = "blue")

#2 a)
x2 <- UBSprices$bigmac2003
y2 <- UBSprices$bigmac2009
plot(x2, y2, xlab = "Big Mac Prices 2003 (in min of labor)", 
     ylab = "Big Mac Prices 2009 (in min of labor)", 
     main = "Big Mac Price Comparison")
# Most of the data points are concentrated between 0-50 minutes of labor,
# indicating that the y values are not independent because there isn't sufficient spread.

#2 b)
logx2 <- log(x2)
logy2 <- log(y2)
plot(logx2, logy2, xlab = "Big Mac Prices 2003 (in min of labor)", 
     ylab = "Big Mac Prices 2009 (in min of labor)", 
     main = "Big Mac Price Comparison")
# The relationship between the predictor and response variable appears to have a 
# better linear relationship compared to the previous plot, and there is good spread for
# the data points.  

#2 c)
Elogx2 <- mean(logx2)
Elogy2 <- mean(logy2)
Sxx2 <- sum((logx2 - Elogx2)^2)
Syy2 <- sum((logy2 - Elogy2)^2)
Sxy2 <- sum((logx2 - Elogx2) * (logy2 - Elogy2))
b12 <- Sxy2/Sxx2
b02 <- Elogy2 - b12*Elogx2
abline(b02, b12, col = "blue")

#3 a)
x3 <- prostate$lpsa
y3 <- prostate$lcavol
plot(x3, y3, xlab = "log(prostate cancer volume)", 
     ylab = "log(cancer volume)",
     main = "Prostate Cancer Analysis of PSA on Volume")
#lpsa on lcavol
abline(lm(y3~x3), col = "blue")
#lcavol on lpsa
lcONlp <- lm(y3~x3)
lpONlc <- lm(x3~y3)
newslope <- 1 / (lcONlp$coeff[2])
newintercept <- (-lpONlc$coeff[1] / lcONlp$coeff[2])
abline(newintercept, newslope, col = "red")

#3 b)
# The two lines intersect at the point (mean of lpsa, mean of lcavol).  
# A property of regression lines states that the specified point will always be 
# a solution for any given line.  

#4 a)
x4 <- Heights$mheight
y4 <- Heights$dheight
plot(x4, y4, xlab = "Mother's Height (in in)", 
     ylab = "Daughter's Height (in in)", 
     main = "Mother/Daughter height")
abline(lm(y4~x4), col = "blue")

#4 b)
Ex4 <- mean(x4)
Ey4 <- mean(y4)
Sxx4 <- sum((x4 - Ex4)^2)
Syy4 <- sum((y4 - Ey4)^2)
Sxy4 <- sum((x4 - Ex4) * (y4 - Ey4))
corrCoeff <- Sxy4/sqrt(Sxx4*Syy4)
#The relationship between dheight and mheight is positive.

#5 a) 

