#1 a)

library(alr4)
data("UN11")

x <- UN11$ppgdp
y <- UN11$fertility

plot(x, y, xlab = "Per Capita GDP (US Dollars)", ylab = "Number of Children Per Women", 
     main = "Affects of Per Capita GDP on the Number of Children a Woman Has")
fit = lm(y ~ x)
abline(fit, col = "blue")
# The fit has a low r-squared, and this

#1 b)

yhat = fitted(fit)
e = y - yhat
plot(yhat, e, xlab = 'Fitted Values', ylab = 'Residual', main = 'Residual vs Fit')
abline(h = 0, lty = 2)

# The residuals don't bounce randomly around the 0 line and this suggests that the relationship isn't linear

#1 c)

qqnorm(e, main = "Normal Q-Q Plot")
qqline(e, col = 'blue')

# There are too many extreme positive and negative residuals, and so the distribution is heavy tailed.  This suggests that the data isn't normally distributed.

#1 d)

shapiro.test(e)
# The p-value is 2.708e-08
# We cannot reject the null hypothesis because the p-value is less than 0.05.    

#2 a)
library(faraway)
data("teengamb")
y1 <- teengamb$gamble
x1 <- teengamb$sex
x2 <- teengamb$status
x3 <- teengamb$income
x4 <- teengamb$verbal

gamble <- lm(y1 ~ x1 + x2 + x3 + x4)

avgmen <- model.matrix(gamble)
avgmen <- apply(avgmen, 2, mean)
avgmen[2] <- 0
avgmen <- avgmen[-1]
predict(gamble, data.frame(t(avgmen)), interval="confidence", level = 0.95)

#I am 95% confident that the true expenditure on gambling in pounds per year for men with average status, income, and verbal score is between 18.78277 and 37.70227.
  
#2 b)
maxmen <- model.matrix(gamble)
maxmen <- apply(maxmen, 2, max)
maxmen[2] <- 0
maxmen <- maxmen[-1]
predict(gamble, new=data.frame(t(maxmen)), interval="confidence", level = 0.95)

#This confidence interval has a wider interval because we are using a maximum instead of a mean.  Maximums aren't a good measure of the sample behavior. 

#2 c)
gamblesqrt <- lm(sqrt(y1) ~ x1 + x2 + x3 + x4)
predict(gamblesqrt, new=data.frame(t(avgmen)), interval="prediction", level = 0.95)^2

#I am 95% confident that the true expenditure on gambling in pounds per year for men with average status, income, and verbal score is between 0.060004216 and 69.6237

#3 a)
data("sat")
x1 <- sat$total 
y1 <- sat$expend
y2 <- sat$takers
totalsat <- lm(x1 ~ y1 + y2)
summary(totalsat)
yhat2 = fitted(totalsat)

# Reject the null hypothesis, one of the predictor variables has a greater p value than the other two. 
# It seems that the expenditure variable has an effect on the response variable.  

#4 a) 
library(SemiPar)
data("trade.union")
x4 <- trade.union$union.member
x3 <- trade.union$age
y3 <- trade.union$wage
plot(x3, y3, xlab = 'Age (in years)', ylab = 'Wage (dollars per hour)', main = "Trade Unions Wage on Age", col = trade.union$union.member + 1)
legend ('topright', legend = paste('Union Member', 0:1), col = 1:2, pch = 20)

#4 b)
fit <- lm(log(y3) ~ x3 + x4)
yhat <- fitted(fit)
e <- log(wage) - yhat
plot(yhat, e, xlab = 'Fitted Values', ylab = 'Residual', main = 'Residual vs Fit')
abline(h = 0, lty = 2)
qqnorm(e, main = 'Normal Q-Q Plot')
qqline(e, col = 'blue')

#4 c)
transformed <- lm(y3 ^ (-0.05) ~ x3 + x4)
plot(x3, y3 ^ (-0.05), pch = as.numeric(x4), xlab = 'Wage', ylab = '')
abline(transformed, col = 'blue')
summary(transformed)

#4 d)
anova(transformed)
# state null n alternative

X <- c(4, 1, 2, 3, 3, 4)
Y <- c(16, 5, 10, 15, 13, 22)

X <- cbind(1, X)
Y <- matrix(Y, ncol = 1)

#5 a) 
YY <- t(Y) %*% Y

#5 b)
XX <- t(X) %*% X

#5 c)
XY <- t(X) %*% Y

#5 d)
b <- solve(XX) %*% XY

#6 https://archive.ics.uci.edu/ml/datasets/Wine+Quality
# We are going to use a dataset on wine quality.  Essentially, we are given features of the wine, such as
# pH, residual sugar, alcohol content, and various sulphate contents.  I think a couple of the 
# variables that would be important are the residual sugar and citric acid content because 
# these two are the most related to taste.  
